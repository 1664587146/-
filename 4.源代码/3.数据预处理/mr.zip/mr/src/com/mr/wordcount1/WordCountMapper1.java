package com.mr.wordcount1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WordCountMapper1 extends Mapper<LongWritable ,Text, Text, IntWritable > {

	
	@Override
	protected void map(LongWritable key, Text value,Context context)
			throws IOException, InterruptedException {
	
		
		String [] str= value.toString().split(" ");
		
		for(int i = 0;i<str.length;i++){
			
			context.write(new Text(str[i]), new IntWritable(1));
		
		}
	}
}

//
//I am rod, I am from China.
//
//I 1
//am 1
//rod 1
//I 1
//am 1