package com.mr.etl;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class RunJob {

	public static void main(String[] args) {
		
		
		Configuration conf =new Configuration();
		
		
		//		conf.set("fs.defaultFS", "hdfs://192.168.173.100:9000");
		//hdfs://node01:8020

		conf.set("fs.defaultFS", "hdfs://node01:8020");
		try {
			FileSystem fs =FileSystem.get(conf);
			Job job =Job.getInstance(conf,"wc");
			
			job.setJarByClass(RunJob.class);
			
			job.setMapperClass(DateUtilMapper.class);
			job.setReducerClass(DateUtilReducer.class);
			
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(Text.class);
			
		
			FileInputFormat.addInputPath(job, new Path("/flume/record/2020-07-23/0925"));
			
			Path output =new Path("/opt/logs/record_dimension/");
			if(fs.exists(output)){
				fs.delete(output, true);
			}
			FileOutputFormat.setOutputPath(job, output);
			
			boolean f= job.waitForCompletion(true);
			if(f){
				System.out.println("job Complete");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
