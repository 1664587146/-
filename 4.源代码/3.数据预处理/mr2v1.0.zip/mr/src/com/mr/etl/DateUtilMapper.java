package com.mr.etl;

import java.io.IOException;
import java.util.*;
import java.text.SimpleDateFormat;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DateUtilMapper extends Mapper<LongWritable, Text, Text, Text>{


	protected void map(LongWritable key, Text value,
			Context context)
			throws IOException, InterruptedException {
		String[] words = value.toString().split(",");

		String content = "";
		float precipitation = 0, help3;
		int help1, help2;
		Random rand = new Random();
		if (words[0] == "北京" || words[0] == "上海" || words[0] == "广州"
				|| words[0] == "深圳" || words[0] == "南京" ||
				words[0] == "重庆" || words[0] == "杭州") {
			for (int i = 0; i < words.length; i++) {
				if (i == 4) {
					switch (words[4]) {
						case "小到中雨":
							words[4] = "小雨";
						case "中到大雨":
							words[4] = "中雨";
						case "雷阵雨":
							words[4] = "阵雨";
						case "阵雨"://20 + rand % 20
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(30);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 0;
							break;
						case "小雨":// 0 + rand %10
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(9);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 0;
							break;
						case "中雨":// 10 + rand %15
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(14);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 10;

							break;
						case "暴雨"://暴雨:1天(或24h)降雨量50~100mm者。
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(49);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 50;
							break;
						case "大暴雨"://大暴雨:1天(或24h)降雨量100~250mm者。
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(149);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 100;
							break;
						case "特大暴雨"://特大暴雨:1天(或24h)降雨量在250mm以上者
							help1 = rand.nextInt(100);
							help2 = rand.nextInt(20);
							help3 = (float) (help1 * 1.0) / 100;
							precipitation = help2 + help3 + 250;
							break;
						default:
							precipitation = 0;
							break;
					}
					content = content + words[i] + "\t";
				} else {
					content = content + words[i] + "\t";
				}
			}
			precipitation = (float) (Math.round(precipitation * 100)) / 100;
			String s = String.valueOf(precipitation);
			content = content + s.toString();
			context.write(new Text(content), new Text(""));
		}
	}
}
