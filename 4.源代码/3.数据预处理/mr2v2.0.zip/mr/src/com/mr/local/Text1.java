package com.mr.local;

import java.io.*;
import java.util.*;

public class Text1 {

    public static void main(String[] args)throws IOException, InterruptedException{
        FileInputStream file1 = new FileInputStream("C:\\Users\\16645\\Desktop\\java\\mr\\src\\com\\mr\\local\\2020-7-25.txt");
        FileOutputStream filew = new FileOutputStream("C:\\Users\\16645\\Desktop\\java\\mr\\src\\com\\mr\\local\\a2020-7-25.txt");

        InputStreamReader in = new InputStreamReader(file1,"UTF-8");
        OutputStreamWriter out = new OutputStreamWriter(filew,"UTF-8");

        BufferedReader ibr = new BufferedReader(in);
        BufferedWriter obr = new BufferedWriter(out);

        //主要是这一块
        String line = "";
        String[] handle = null;
        String strOut = null;
        line = ibr.readLine();
        handle =line.split(",");
        Random rand = new Random();

        for (int i = 0; i < handle.length ; i++){
                strOut = handle[i] + '\t';
        }
        obr.write(strOut +"precipitation\n");

        float precipitation = 0,help3;
        int help1 , help2;
        while ((line = ibr.readLine() ) != null) {
            handle = line.split(",");
            if ( handle[0].compareTo("北京") == 0 || handle[0].compareTo("上海") == 0
                    || handle[0].compareTo("广州") == 0 || handle[0].compareTo("深圳") == 0
                    || handle[0].compareTo("南京") == 0 || handle[0].compareTo("杭州") == 0
                    || handle[0].compareTo("重庆") == 0 ) {
                for (int i = 0; i < handle.length; i++) {
                    if (i == 4) {
                        switch (handle[4]) {
                            case "小到中雨":
                                handle[4] = "小雨";
                            case "中到大雨":
                                handle[4] = "中雨";
                            case "雷阵雨":
                                handle[4] = "阵雨";
                            case "阵雨"://20 + rand % 20
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(30);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 0;
                                break;
                            case "小雨":// 0 + rand %10
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(9);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 0;
                                break;
                            case "中雨":// 10 + rand %15
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(14);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 10;

                                break;
                            case "暴雨"://暴雨:1天(或24h)降雨量50~100mm者。
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(49);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 50;
                                break;
                            case "大暴雨"://大暴雨:1天(或24h)降雨量100~250mm者。
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(149);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 100;
                                break;
                            case "特大暴雨"://特大暴雨:1天(或24h)降雨量在250mm以上者
                                help1 = rand.nextInt(100) % 100;
                                help2 = rand.nextInt(20);
                                help3 = (float) (help1 * 1.0) / 100;
                                precipitation = help2 + help3 + 250;
                                break;
                            default:
                                precipitation = 0;
                                break;
                        }
                    }
                    System.out.print(handle[i].toString() + "\t");
                    obr.write(handle[i].toString() + "\t");//文件写
                }
                precipitation = (float) (Math.round(precipitation * 100)) / 100;
                String s = String.valueOf(precipitation);
                System.out.print(s.toString() + "\n");
                obr.write(s.toString() + "\n");//文件写
            }
        }
        ibr.close();
        in.close();
        file1.close();

        obr.close();
        out.close();
        filew.close();
    }
}