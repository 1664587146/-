package com.mr.wordcount;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable>{

	/**
	 * 循环调用的方法，一行调用一次。
	 * 输入的数据格式（默认的格式）
	 * @param key  : 该行的下标
	 * @param value :该行的内容
	 * 
	 */
	protected void map(LongWritable key, Text value,
			Context context)
			throws IOException, InterruptedException {
		String[] words =value.toString().split(" ");
		for(String w :words){
			context.write(new Text(w), new IntWritable(1));
		}
	}
}
