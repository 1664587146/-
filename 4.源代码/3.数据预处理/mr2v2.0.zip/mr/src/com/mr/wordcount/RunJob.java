package com.mr.wordcount;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class RunJob {

	public static void main(String[] args) {
		
		
		Configuration conf =new Configuration();
		//conf.set("fs.defaultFS", "hdfs://123.207.114.130:9000");
		conf.set("fs.defaultFS", "hdfs://192.168.236.100:9000");
		 
		
		try {
			FileSystem fs =FileSystem.get(conf);
			Job job =Job.getInstance(conf,"wc");
			
			job.setJarByClass(RunJob.class);
			
			job.setMapperClass(WordCountMapper.class);
			job.setReducerClass(WordReducer.class);
			
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(IntWritable.class);
			
		
			FileInputFormat.addInputPath(job, new Path("/usr/input/"));
			
			Path output =new Path("/usr/output7/");
			if(fs.exists(output)){
				fs.delete(output, true);
			}
			FileOutputFormat.setOutputPath(job, output);
			
			boolean f= job.waitForCompletion(true);
			if(f){
				System.out.println("job Finished");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
